<?php
require('db.inc.php');
if (!isset($_SESSION['USERNAME'])) {
    header('location:login.php');
    die();
}
error_reporting(0);

$hobbiesArray = [];

$showTable = false;
$showTable2 = false;


$username = $_SESSION['USERNAME'];

$users1 = "SELECT * FROM users";
$usersResult1 = mysqli_query($con, $users1);
$usersResult2 = mysqli_query($con, $users1);
$usersResult3 = mysqli_query($con, $users1);

$query1 = "SELECT * FROM `tags` as t LEFT JOIN posts as p ON p.post_id=t.post_id LEFT JOIN users as u ON u.username=p.username WHERE t.tag='blockchain' OR t.tag='SQL' GROUP BY t.username HAVING COUNT(t.username)>=2";
$result1 = mysqli_query($con, $query1);


if (isset($_POST['query2'])) {
    $userx = mysqli_real_escape_string($con, $_POST['userslistQuery2']);
    // $query2="SELECT * FROM posts WHERE username='$userx' AND post_id IN (SELECT post_id FROM comments WHERE sentiment = 'positive' GROUP BY post_id)";
    $query2 = "SELECT * FROM posts WHERE username='$userx' AND post_id IN (SELECT post_id FROM comments com WHERE com.sentiment ='positive' and com.post_id in (select post_id from comments GROUP BY post_id HAVING COUNT(DISTINCT(sentiment)) = 1 ))";
    $result2 = mysqli_query($con, $query2);
}


// $query3="SELECT *,COUNT(p.username)as total FROM `posts` as p LEFT JOIN users as u ON p.username=u.username WHERE p.created_on='2022-04-26' GROUP BY p.username ORDER BY total DESC LIMIT 1";
$query3 = "select * from posts as p left join users as u on p.username = u.username WHERE p.created_on='2022-05-01' group by p.username having count(p.username) =(select max(data.count) from (select count(p.username) as count from posts as p WHERE p.created_on='2022-05-01' group by p.username) data)";
$result3 = mysqli_query($con, $query3);

if (isset($_POST['submit'])) {
    $user1 = mysqli_real_escape_string($con, $_POST['userslist1']);
    $user2 = mysqli_real_escape_string($con, $_POST['userslist2']);
    $query4 = "SELECT * FROM users WHERE users.username IN (SELECT DISTINCT username from followers where follower = '$user1' and username in ( select username from followers where follower = '$user2'))";
    $result4 = mysqli_query($con, $query4);
    $showTable = true;
}

$query5 = "SELECT * from hobbies";
$result5 = mysqli_query($con, $query5);
if (mysqli_num_rows($result5) > 0) {
    while ($hobbies = mysqli_fetch_assoc($result5)) {
        if($hobbiesArray[$hobbies["hobby"]] == []){
            $hobbiesArray[$hobbies["hobby"]] = array($hobbies["username"]);
        }
        else{
            $hobbiesArray[$hobbies["hobby"]] = array_merge($hobbiesArray[$hobbies["hobby"]],array($hobbies["username"]) );
        }
    }
}

$query6 = "select * from users usr where usr.username not in (select distinct(username) from posts)";
$result6 = mysqli_query($con, $query6);

$query7 = "select * from users usr where usr.username not in (select distinct(username) from comments)";
$result7 = mysqli_query($con, $query7);

$query8 = "SELECT * from users where username in ( select username from comments com where com.sentiment = 'negative' and com.username in (select username from comments GROUP BY username HAVING COUNT(DISTINCT(sentiment)) = 1 ) )";
$result8 = mysqli_query($con, $query8);

$query9 = "SELECT * FROM users WHERE username IN (SELECT username FROM posts WHERE post_id IN (SELECT post_id FROM comments com WHERE com.sentiment ='positive' and com.post_id in (select post_id from comments GROUP BY post_id HAVING COUNT(DISTINCT(sentiment)) = 1 )))";
$result9 = mysqli_query($con, $query9);

?>
<!doctype html>
<html class="no-js" lang="">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Blog Page</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous">
    </script>
    <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
    </script>
    <link href="styles/styles.css" rel="stylesheet" type="text/css">
</head>

<body class="bg-slate-200">

    <div class="space-y-4">
        <nav class="navbar navbar-expand-lg navbar-light bg-light px-4 py-3">
            <a class="navbar-brand" href="#">Blog Website</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="home.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="more-details.php">More Details <span class="sr-only">(current)</span></a>
                    </li>
                </ul>
                <div class="btn-group dropleft">
                    <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                        Profile
                    </button>
                    <div class="dropdown-menu ml-4">
                        <a class="dropdown-item" href="#"><?php echo $username ?></a>
                        <a href="logout.php" class="dropdown-item">
                            Logout
                        </a>
                    </div>
                </div>
                <a href="add-post.php" class="ml-4">
                    <button type="button" class="btn btn-success">Create Post</button>
                </a>

            </div>
        </nav>


        <div class="flex flex-col space-y-16">
            <div class="px-4 sm:px-6 lg:px-8">
                <div class="sm:flex sm:items-center">
                    <div class="sm:flex-auto">
                        <h1 class="text-xl font-semibold text-gray-900">List the users who post at least two blogs, one
                            has a tag of “X”, and another has a
                            tag of “Y”.</h1>
                    </div>
                </div>
                <div class="mt-8 flex flex-col">
                    <div class="-my-2 -mx-4 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div class="inline-block w-full py-2 align-middle md:px-6 lg:px-8">
                            <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                                <table class="w-full divide-y divide-gray-300">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900 sm:pl-6">
                                                Name</th>
                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900">Email
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-gray-200 bg-white">
                                        <?php
                                        while ($rows = mysqli_fetch_assoc($result1)) { ?>
                                            <tr>
                                                <td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">
                                                    <?php echo $rows['username']; ?></td>
                                                <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                                    <?php echo $rows['email']; ?></td>
                                            </tr>
                                        <?php
                                        } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Query 2 -->
            <div class="px-4 sm:px-6 lg:px-8">
                <div class="sm:flex sm:items-center">
                    <div class="sm:flex-auto">
                        <h1 class="text-xl font-semibold text-gray-900">List all the blogs of user X, such that all the
                            comments are positive for these blogs.</h1>
                    </div>
                </div>
                <form class="space-y-4 mt-4" method="post">
                    <div class="form-group space-y-2">
                        <label for="exampleFormControlSelect1">User</label>
                        <select required name="userslistQuery2" class="form-control" id="exampleFormControlSelect1" required>
                            <option disabled selected value> -- select an option -- </option>
                            <?php
                            while ($rows = mysqli_fetch_assoc($usersResult3)) { ?>
                                <option><?php echo $rows['username']; ?></option>
                            <?php
                            } ?>
                        </select>
                    </div>
                    <button type="submit" name="query2" class="inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        Submit</button>
                </form>

                <div class="mt-8 flex flex-col">
                    <div class="-my-2 -mx-4 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div class="inline-block w-full py-2 align-middle md:px-6 lg:px-8">
                            <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                                <table class="w-full divide-y divide-gray-300">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900 sm:pl-6">
                                                Username</th>
                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900">Subject
                                            </th>
                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900">
                                                Description
                                            </th>

                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900">
                                                Created on
                                            </th>

                                        </tr>
                                    </thead>
                                    <?php
                                    if ($showTable2) { ?>
                                        <tbody class="divide-y divide-gray-200 bg-white">
                                            <?php
                                            while ($rows = mysqli_fetch_assoc($result2)) { ?>
                                                <tr>
                                                    <td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">
                                                        <?php echo $rows['username']; ?></td>
                                                    <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                                        <?php echo $rows['subject']; ?></td>
                                                    <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                                        <?php echo $rows['description']; ?></td>
                                                    <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                                        <div class="text-indigo-600 hover:text-indigo-900">
                                                            <?php echo $rows['created_on']; ?></div>
                                                    </td>
                                                </tr>
                                            <?php
                                            } ?>
                                        </tbody>
                                    <?php
                                    } ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Query 3 -->
            <div class="px-4 sm:px-6 lg:px-8">
                <div class="sm:flex sm:items-center">
                    <div class="sm:flex-auto">
                        <h1 class="text-xl font-semibold text-gray-900">List the users who posted the most number of
                            blogs on 5/1/2022; if there is a tie,
                            list all the users who have a tie.</h1>
                    </div>
                </div>
                <div class="mt-8 flex flex-col">
                    <div class="-my-2 -mx-4 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div class="inline-block w-full py-2 align-middle md:px-6 lg:px-8">
                            <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                                <table class="w-full divide-y divide-gray-300">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900 sm:pl-6">
                                                Name</th>
                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900">Email
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-gray-200 bg-white">
                                        <?php
                                        while ($rows = mysqli_fetch_assoc($result3)) { ?>
                                            <tr>
                                                <td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">
                                                    <?php echo $rows['username']; ?></td>
                                                <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                                    <?php echo $rows['email']; ?></td>
                                            </tr>
                                        <?php
                                        } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Query 4 -->

            <div class="px-4 sm:px-6 lg:px-8">
                <div class="sm:flex sm:items-center">
                    <div class="sm:flex-auto">
                        <h1 class="text-xl font-semibold text-gray-900">List the users who are followed by both X and Y.
                            Usernames X and Y are inputs
                            from the user.</h1>
                    </div>
                </div>
                <form class="space-y-4 mt-4" method="post">
                    <div class="form-group space-y-2">
                        <label for="exampleFormControlSelect1">User 1</label>
                        <select required name="userslist1" class="form-control" id="exampleFormControlSelect1" required>
                            <option disabled selected value> -- select an option -- </option>
                            <?php
                            while ($rows = mysqli_fetch_assoc($usersResult1)) { ?>
                                <option><?php echo $rows['username']; ?></option>
                            <?php
                            } ?>
                        </select>
                    </div>

                    <div class="form-group space-y-2">
                        <label for="exampleFormControlSelect1">User 2</label>
                        <select required name="userslist2" class="form-control" id="exampleFormControlSelect1" required>
                            <option disabled selected value> -- select an option -- </option>
                            <?php
                            while ($rows = mysqli_fetch_assoc($usersResult2)) { ?>
                                <option><?php echo $rows['username']; ?></option>
                            <?php
                            } ?>
                        </select>
                    </div>
                    <button type="submit" name="submit" class="inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        Submit</button>
                </form>
                <div class="mt-8 flex flex-col">
                    <div class="-my-2 -mx-4 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div class="inline-block w-full py-2 align-middle md:px-6 lg:px-8">
                            <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                                <table class="w-full divide-y divide-gray-300">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900 sm:pl-6">
                                                Name</th>
                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900">Email
                                            </th>
                                        </tr>
                                    </thead>
                                    <?php
                                    if ($showTable) { ?>
                                        <tbody class="divide-y divide-gray-200 bg-white">
                                            <?php
                                            while ($rows = mysqli_fetch_assoc($result4)) { ?>
                                                <tr>
                                                    <td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">
                                                        <?php echo $rows['username']; ?></td>
                                                    <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                                        <?php echo $rows['email']; ?></td>
                                                </tr>
                                            <?php
                                            } ?>
                                        </tbody>
                                    <?php
                                    } ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Query 5 -->

            <div class="px-4 sm:px-6 lg:px-8">
                <div class="sm:flex sm:items-center">
                    <div class="sm:flex-auto">
                        <h1 class="text-xl font-semibold text-gray-900">List a user pair (A, B) such that they have at
                            least one common hobby.</h1>
                    </div>
                </div>
                <div class="mt-8 flex flex-col">
                    <div class="-my-2 -mx-4 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div class="inline-block w-full py-2 align-middle md:px-6 lg:px-8">
                            <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                                <table class="w-full divide-y divide-gray-300">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900 sm:pl-6">
                                                Name</th>
                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900">Hobby
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-gray-200 bg-white">
                                        <?php
                                        foreach ($hobbiesArray as $key => $value) { ?>
                                        <?php
                                        if (sizeof($value)>1) { ?>
                                            <tr>
                                                <td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">
                                                    <?php echo implode(" , ",$value) ?></td>
                                                <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                                    <?php echo $key ?></td>
                                            </tr>
                                            <?php
                                        } ?>
                                        <?php
                                        } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Query 6 -->

            <div class="px-4 sm:px-6 lg:px-8">
                <div class="sm:flex sm:items-center">
                    <div class="sm:flex-auto">
                        <h1 class="text-xl font-semibold text-gray-900">Display all the users who never posted a blog.
                        </h1>
                    </div>
                </div>
                <div class="mt-8 flex flex-col">
                    <div class="-my-2 -mx-4 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div class="inline-block w-full py-2 align-middle md:px-6 lg:px-8">
                            <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                                <table class="w-full divide-y divide-gray-300">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900 sm:pl-6">
                                                Username</th>
                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900">Email Id
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-gray-200 bg-white">
                                        <?php
                                        while ($rows = mysqli_fetch_assoc($result6)) { ?>
                                            <tr>
                                                <td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">
                                                    <?php echo $rows['username']; ?></td>
                                                <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                                    <?php echo $rows['email']; ?></td>
                                            </tr>
                                        <?php
                                        } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!--Query 7  -->

            <div class="px-4 sm:px-6 lg:px-8">
                <div class="sm:flex sm:items-center">
                    <div class="sm:flex-auto">
                        <h1 class="text-xl font-semibold text-gray-900">Display all the users who never posted a
                            comment.</h1>
                    </div>
                </div>
                <div class="mt-8 flex flex-col">
                    <div class="-my-2 -mx-4 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div class="inline-block w-full py-2 align-middle md:px-6 lg:px-8">
                            <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                                <table class="w-full divide-y divide-gray-300">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900 sm:pl-6">
                                                Name</th>
                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900">Email
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-gray-200 bg-white">
                                        <?php
                                        while ($rows = mysqli_fetch_assoc($result7)) { ?>
                                            <tr>
                                                <td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">
                                                    <?php echo $rows['username']; ?></td>
                                                <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                                    <?php echo $rows['email']; ?></td>
                                            </tr>
                                        <?php
                                        } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!--Query 8  -->

            <div class="px-4 sm:px-6 lg:px-8">
                <div class="sm:flex sm:items-center">
                    <div class="sm:flex-auto">
                        <h1 class="text-xl font-semibold text-gray-900">Display all the users who posted some comments,
                            but each of them is negative.</h1>
                    </div>
                </div>
                <div class="mt-8 flex flex-col">
                    <div class="-my-2 -mx-4 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div class="inline-block w-full py-2 align-middle md:px-6 lg:px-8">
                            <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                                <table class="w-full divide-y divide-gray-300">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900 sm:pl-6">
                                                Name</th>
                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900">Email
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-gray-200 bg-white">
                                        <?php
                                        while ($rows = mysqli_fetch_assoc($result8)) { ?>
                                            <tr>
                                                <td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">
                                                    <?php echo $rows['username']; ?></td>
                                                <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                                    <?php echo $rows['email']; ?></td>
                                            </tr>
                                        <?php
                                        } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="px-4 sm:px-6 lg:px-8">
                <div class="sm:flex sm:items-center">
                    <div class="sm:flex-auto">
                        <h1 class="text-xl font-semibold text-gray-900">Display those users such that all the blogs they
                            posted so far never received any
                            negative comments.</h1>
                    </div>
                </div>
                <div class="mt-8 flex flex-col">
                    <div class="-my-2 -mx-4 overflow-x-auto sm:-mx-6 lg:-mx-8">
                        <div class="inline-block w-full py-2 align-middle md:px-6 lg:px-8">
                            <div class="overflow-hidden shadow ring-1 ring-black ring-opacity-5 md:rounded-lg">
                                <table class="w-full divide-y divide-gray-300">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900 sm:pl-6">
                                                Name</th>
                                            <th scope="col" class="py-3 px-4 text-left text-sm font-semibold text-gray-900">Email
                                            </th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-gray-200 bg-white">
                                        <?php
                                        while ($rows = mysqli_fetch_assoc($result9)) { ?>
                                            <tr>
                                                <td class="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6">
                                                    <?php echo $rows['username']; ?></td>
                                                <td class="whitespace-nowrap px-3 py-4 text-sm text-gray-500">
                                                    <?php echo $rows['email']; ?></td>
                                            </tr>
                                        <?php
                                        } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

</body>

</html>