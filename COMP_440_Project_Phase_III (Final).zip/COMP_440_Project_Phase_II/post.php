<?php
require('db.inc.php');
$msg = "";
$error_msg = "";
$sentiment = "";
$description = "";
$username = $_SESSION['USERNAME'];
$createdOn = date("Y-m-d");
$totalCommentscount = 0;
$postId = $_GET['id'];
$isEnableComment = true;
$followingUser = "";
$isAlreadyFollowed = false;

if (!isset($_SESSION['USERNAME'])) {
    header('location:login.php');
    die();
}
$getPost = "select * from posts where post_id='$postId'";
$res = mysqli_query($con, $getPost);

$getTags = "select * from tags where post_id='$postId'";
$tagsresponse = mysqli_query($con, $getTags);


$comments = "select * from comments where post_id='$postId'";
$commentsRes = mysqli_query($con, $comments);

// echo "<script> alert('Followed Successfully $followingUser')</script>";
// $followersQuery = "select * from followers where follower='$username' and username='$followingUser'";
// if ($con->query($followersQuery) === TRUE) {
//     $isAlreadyFollowed=true;
// }



if (isset($_GET['follow'])) {
    $follower = $username;
    $usernameToFollow = $_GET['follow'];
    $followers = "select count(username) as total from followers where username='$usernameToFollow' and follower='$follower'";
    $limitCheck = mysqli_query($con, $followers);
    if (mysqli_num_rows($limitCheck) > 0) {
        while ($total = mysqli_fetch_assoc($limitCheck)) {
            $totalCount = $total["total"];
        }
    }
    if ($totalCount != 1) {
        $sql = "insert into followers(username,follower,followed_on) values('$usernameToFollow','$follower','$createdOn')";
        if ($con->query($sql) === TRUE) {
            echo "<script> alert('Followed Successfully')</script>";
            header(`location:post.php?id=$postId`);
            echo "<meta http-equiv='refresh' content='0'>";
        } else {
            echo "<script> alert(`Error following $con->error`)</script>";
            header(`location:post.php?id=$postId`);
            $error_msg = "Error posting: " . $con->error;
        }
    } else {
        echo "<script> alert(`Already Following`)</script>";
        header(`location:post.php?id=$postId`);
    }
}


if (isset($_POST['submit'])) {
    $query = "select count(comment_id) as total from comments where username='$username' and created_on='$createdOn'";
    $limitCheck = mysqli_query($con, $query);
    if (mysqli_num_rows($limitCheck) > 0) {
        while ($total = mysqli_fetch_assoc($limitCheck)) {
            $totalCommentscount = $total["total"];
        }
    }

    $query = "select count(comment_id) as total from comments where username='$username' and post_id='$postId'";
    $commentLimitCheck = mysqli_query($con, $query);
    if (mysqli_num_rows($commentLimitCheck) > 0) {
        while ($postCommentTotal = mysqli_fetch_assoc($commentLimitCheck)) {
            $commentOnPostcount = $postCommentTotal["total"];
        }
    }

    if ($totalCommentscount < 3 && $commentOnPostcount < 1) {
        $sentiment = mysqli_real_escape_string($con, $_POST['sentiment']);
        $description = mysqli_real_escape_string($con, $_POST['description']);
        $sql = "insert into comments(post_id,username,sentiment,description,created_on) values('$postId','$username','$sentiment','$description','$createdOn')";
        if ($con->query($sql) === TRUE) {
            $msg = "Posted Successful";
            echo "<script> alert('Posted Successful')</script>";
            echo "<meta http-equiv='refresh' content='0'>";
        } else {
            echo "<script> alert('Error posting')</script>";
            $error_msg = "Error posting: " . $con->error;
        }
    } else if ($totalCommentscount >= 3) {
        $error_msg = "Max Limit Reached. A user can comment only 3 times a day";
    } else if ($commentOnPostcount >= 1) {
        $error_msg = "Max Limit Reached. A user can comment on post only once";
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Post</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous">
    </script>
    <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous">
    </script>
    <link href="styles/styles.css" rel="stylesheet" type="text/css">
</head>

<body>
    <div>
        <nav class="navbar navbar-expand-lg navbar-light bg-light px-4 py-3">
            <a class="navbar-brand" href="#">Blog Website</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="home.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="more-details.php">More Details <span class="sr-only">(current)</span></a>
                    </li>
                </ul>
                <div class="btn-group dropleft">
                    <button type="button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                        Profile
                    </button>
                    <div class="dropdown-menu ml-4">
                        <a class="dropdown-item" href="#"><?php echo $username ?></a>
                        <a href="logout.php" class="dropdown-item">
                            Logout
                        </a>
                    </div>
                </div>
                <a href="add-post.php" class="ml-4">
                    <button type="button" class="btn btn-success">Create Post</button>
                </a>
            </div>
        </nav>
        <div class="p-4 mx-auto w-3/4 space-y-4">
            <?php
            while ($post = mysqli_fetch_assoc($res)) { ?>
                <?php if ($post['username'] == $username) { ?>
                    <?php $isEnableComment = false; ?>
                <?php } ?>
                <?php $followingUser = $post['username'] ?>
                <div class="flex text-sm space-x-4 cursor-pointer shadow-sm bg-white rounded-lg px-4 py-2">
                    <div class="flex-none py-10">
                        <img src="images/image.png" alt="" class="w-10 h-10 bg-gray-100 rounded-full">
                    </div>
                    <div class="flex-1 py-10 space-y-1">
                        <div class="max-w-none flex flex-row justify-between">
                            <div class="flex flex-col space-y-2">
                                <h3 class="font-medium text-gray-900"><?php echo $post['username']; ?></h3>
                                <p class="text-gray-700"><?php echo $post['created_on']; ?></p>
                            </div>
                            <div>
                                <?php if ($username != $post['username']) { ?>
                                    <a href="post.php?id=<?php echo $post['post_id'] ?>&follow=<?php echo $post['username'] ?>">
                                        <button type="button" class="w-full bg-indigo-600 p-2 border border-transparent rounded-md flex items-center justify-center text-md font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 sm:w-auto sm:inline-flex">
                                            Follow User
                                        </button>
                                    </a>
                                <?php } ?>
                            </div>
                        </div>

                        <div class="flex flex-row items-end justify-start space-x-4">
                            <div class="mt-4 max-w-none font-bold text-md text-slate-900"><?php echo $post['subject']; ?>
                            </div>
                            <?php
                            while ($tags = mysqli_fetch_assoc($tagsresponse)) { ?>
                                <span class="inline-block px-2 py-0.5 text-green-800 text-sm font-medium bg-green-100 rounded-full">
                                    <?php echo $tags['tag']; ?>
                                </span>
                            <?php
                            }
                            ?>
                        </div>
                        <div class="mt-3 max-w-none text-slate-900">
                            <?php echo $post['description']; ?>
                        </div>
                    </div>
                </div>
            <?php
            }
            ?>
        </div>
        <?php if ($error_msg != '') { ?>
            <div class="alert alert-danger mx-auto w-2/3" role="alert"><?php echo $error_msg ?></div>
        <?php } ?>
        <section aria-labelledby="notes-title">
            <div class="p-4 mx-auto w-3/4">
                <div class="divide-y divide-gray-200">
                    <div class="p-4">
                        <h2 id="notes-title" class="text-lg font-medium text-gray-900">Comments</h2>
                    </div>
                    <div class="px-4 py-6 sm:px-6">
                        <ul role="list" class="space-y-8">
                            <?php
                            while ($comments = mysqli_fetch_assoc($commentsRes)) { ?>
                                <li>
                                    <div class="flex space-x-3">
                                        <div class="flex-shrink-0">
                                            <img class="h-10 w-10 rounded-full" src="images/image.png" alt="Image">
                                        </div>
                                        <div>
                                            <div class="text-sm font-medium text-gray-900">
                                                <?php echo $comments['username']; ?>
                                            </div>
                                            <div class="mt-1 text-sm text-gray-700">
                                                <p><?php echo $comments['description']; ?></p>
                                            </div>
                                            <div class="mt-2 text-sm space-x-2">
                                                <span class="text-gray-500 font-medium"><?php echo $comments['created_on']; ?>
                                                    </p></span>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            <?php
                            }
                            ?>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <?php if ($isEnableComment) { ?>
            <div class="p-4 mx-auto w-2/3 space-y-4">
                <p class="text-xl font-bold">Add Comment</p>
                <form class="space-y-4" method="post">
                    <div class="form-group space-y-2">
                        <label for="exampleFormControlSelect1">Sentiment</label>
                        <select required name="sentiment" class="form-control" id="exampleFormControlSelect1">
                            <option disabled selected value> -- select an option -- </option>
                            <option>Positive</option>
                            <option>Negative</option>
                        </select>
                    </div>
                    <div class="form-group space-y-2">
                        <label for="exampleFormControlTextarea1">Description</label>
                        <textarea required class="form-control" name="description" required id="exampleFormControlTextarea1" rows="3"></textarea>
                    </div>
                    <button type="submit" name="submit" class="inline-flex items-center justify-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">Add
                        Comment</button>
                </form>
            </div>
        <?php } ?>

    </div>
</body>

</html>