<?php
require('db.inc.php');
$msg = "";
$error_msg = "";
$userName = "";
$password = "";
$confirmPassword = "";
$hobbies="";
$firstName = "";
$lastName = '';
$email = '';
$errors = [];

if (isset($_POST['submit'])) {
   $username = mysqli_real_escape_string($con, $_POST['username']);
   $email = mysqli_real_escape_string($con, $_POST['email']);
   $firstName = mysqli_real_escape_string($con, $_POST['firstName']);
   $lastName = mysqli_real_escape_string($con, $_POST['lastName']);
   $password = mysqli_real_escape_string($con, $_POST['password']);
   $confirmPassword = mysqli_real_escape_string($con, $_POST['confirmPassword']);
   $hobbies = $_POST['hobbies'];

   if ($password == $confirmPassword) {
      $sql = "insert into users(username,password,firstName,lastName,email) values('$username','$password','$firstName','$lastName','$email')";
      // mysqli_query($con, $sql);
      if ($con->query($sql) === TRUE) {
         $msg = "Signup successful";
         echo "<script> alert('Signup successful')</script>";
         foreach ($hobbies as $hobby) {
            $insertHobbies="insert into hobbies(username,hobby) values('$username','$hobby')";
            if ($con->query($insertHobbies) === TRUE) {
                echo "<script> alert('Hobbies inserted Successful')</script>";
             } else {
                echo "<script> alert('Error inserting hobbies')</script>";
                $error_msg = "Error hobbies: " . $con->error;
             }
         }
         header('location:login.php');
      } else {
         echo "<script> alert('Error creating user')</script>";
         $error_msg = "Error creating user: " . $con->error;
      }
      // die();
   } else {
      $error_msg = "Password Do not match";
      echo "<script> alert('Password Do not match')</script>";
   }
}

if (isset($_GET['init'])) {
   $errors = [];
   $table1 = "CREATE TABLE Users ( username VARCHAR(20) NOT NULL ,password VARCHAR(20) NOT NULL ,  
   firstName VARCHAR(20) NOT NULL ,lastName VARCHAR(20) NOT NULL ,email VARCHAR(30) NOT NULL ,
   PRIMARY KEY (username), UNIQUE (email,username) )";

   $table2 = "CREATE TABLE posts ( post_id INT(50) NOT NULL AUTO_INCREMENT ,subject VARCHAR(50) NOT NULL , 
   description LONGTEXT NOT NULL ,username VARCHAR(50) NOT NULL ,created_on DATE NOT NULL , 
   PRIMARY KEY (post_id) )";

   $table3 = "CREATE TABLE comments (
      `comment_id` int(11) NOT NULL AUTO_INCREMENT,
      `post_id` int(11) NOT NULL,
      `username` varchar(50) NOT NULL,
      `sentiment` varchar(50) NOT NULL,
      `description` longtext NOT NULL,
      `created_on` date NOT NULL,
      PRIMARY KEY (`comment_id`))";

   $table4 = "CREATE TABLE followers ( id INT(50) NOT NULL AUTO_INCREMENT , username VARCHAR(50) NOT NULL , follower VARCHAR(50) NOT NULL ,followed_on DATE NOT NULL, PRIMARY KEY (`id`) )";   

   $table5 = "CREATE TABLE tags ( tag_id INT(50) NOT NULL AUTO_INCREMENT , post_id INT(50) NOT NULL, username VARCHAR(50) NOT NULL , tag VARCHAR(50) NOT NULL , PRIMARY KEY (`tag_id`) )";   

   $table6 = "CREATE TABLE hobbies ( hobby_id INT(50) NOT NULL AUTO_INCREMENT , username VARCHAR(50) NOT NULL , hobby VARCHAR(50) NOT NULL, PRIMARY KEY (`hobby_id`) )";   

   $tables = [$table1, $table2,$table3,$table4,$table5,$table6];

   foreach($tables as $k => $sql){
    $query = @$con->query($sql);

    if(!$query)
       $errors[] = "Table $k : Creation failed ($con->error)";
    else
       $errors[] = "Table $k : Creation done";
   }
}

?>
<!doctype html>
<html class="no-js" lang="">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>University Signup Page</title>
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
   <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"
      integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous">
   </script>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
      integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous">
   </script>
   <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
   <link href="styles/styles.css" rel="stylesheet" type="text/css">
</head>

<body>
   <div class="login-content ">
      <div id="form" class="login-form shadow">
         <form method="post">
            <div>
               <h2 class="title font-semibold text-xl">University Student Signup</h2>
            </div>
            <div class="form-group my-4">
               <label id="label" class="mb-2"> &nbsp;Username </label>
               <input type="text" name="username" class="form-control" placeholder="Username" required>
            </div>
            <div class="form-group space-y-2">
               <label for="exampleFormControlSelect1">Hobbies</label>
               <select required name="hobbies[]" multiple="multiple" class="form-control" id="exampleFormControlSelect1">
                  <option>hiking</option>
                  <option>swimming</option>
                  <option>calligraphy</option>
                  <option>bowling</option>
                  <option>movie</option>
                  <option>cooking</option>
                  <option>dancing</option>
               </select>
            </div>
            <div class="form-group my-4">
               <label id="label" class="mb-2">First Name</label>
               <input type="text" name="firstName" class="form-control" placeholder="First Name" required>
            </div>
            <div class="form-group my-4">
               <label id="label" class="mb-2">Last Name</label>
               <input type="text" name="lastName" class="form-control" placeholder="Last Name" required>
            </div>
            <div class="form-group my-4">
               <label id="label" class="mb-2">Email</label>
               <input type="email" name="email" class="form-control" placeholder="Email" required>
            </div>
            <div class="form-group my-4">
               <label id="label" class="mb-2">Password</label>
               <input type="password" name="password" class="form-control" placeholder="Password" required>
            </div>
            <div class="form-group my-4">
               <label id="label" class="mb-2" class="my-2">Confirm Password</label>
               <input type="password" name="confirmPassword" class="form-control" placeholder="Confirm Password"
                  required>
            </div>
            <div class="d-flex flex-row justify-content-between align-items-center my-4">
               <button type="submit" name="submit" class="btn btn-success btn-flat">Sign Up</button>
               <a href='register.php?init=true'>
                  <button type="button" name="init" class="btn btn-success btn-flat">Initialise Database</button>
               </a>
            </div>
            <?php foreach($errors as $msg) { ?>
            <div class="alert alert-success my-4" role="alert"><?php echo $msg ?></div>
            <?php } ?>
            <?php if ($error_msg != '') { ?>
            <div class="alert alert-danger my-4" role="alert"><?php echo $error_msg ?></div>
            <?php } ?>
         </form>
         <div class="relative">
            <div class="absolute inset-0 flex items-center">
               <div class="w-full border-t border-gray-300"></div>
            </div>
            <div class="relative flex justify-center text-md">
               <span class="px-2 bg-white text-gray-800"> Or </span>
            </div>
         </div>
         <div class="form-group my-4">
            <a href='login.php'>
               <button type="button" name="init" class="btn btn-primary form-control">Sign In</button>
            </a>
         </div>
      </div>
   </div>
</body>

</html>