<?php
require('db.inc.php');
$msg = "";
$error_msg = "";
$errors = [];
if (isset($_POST['username']) && isset($_POST['password'])) {
   $username = mysqli_real_escape_string($con, $_POST['username']);
   $password = mysqli_real_escape_string($con, $_POST['password']);
   $res = mysqli_query($con, "select * from users where username='$username' and password='$password'");
   $count = mysqli_num_rows($res);
   if ($count > 0) {
      $row = mysqli_fetch_assoc($res);
      $_SESSION['USERNAME'] = $row['username'];
      header('location:home.php');
      die();
   } else {
      $error_msg = "Please enter valid login details";
   }
}


if (isset($_GET['init'])) {

   $errors = [];

   $table1 = "CREATE TABLE Users ( username VARCHAR(20) NOT NULL ,password VARCHAR(20) NOT NULL ,  
   firstName VARCHAR(20) NOT NULL ,lastName VARCHAR(20) NOT NULL ,email VARCHAR(30) NOT NULL ,
   PRIMARY KEY (username), UNIQUE (email,username) )";

   $table2 = "CREATE TABLE posts ( post_id INT(50) NOT NULL AUTO_INCREMENT ,subject VARCHAR(50) NOT NULL , 
   description LONGTEXT NOT NULL ,username VARCHAR(50) NOT NULL ,created_on DATE NOT NULL , 
   PRIMARY KEY (post_id) )";

   $table3 = "CREATE TABLE comments (
      `comment_id` int(11) NOT NULL AUTO_INCREMENT,
      `post_id` int(11) NOT NULL,
      `username` varchar(50) NOT NULL,
      `sentiment` varchar(50) NOT NULL,
      `description` longtext NOT NULL,
      `created_on` date NOT NULL,
      PRIMARY KEY (`comment_id`))";

   $table4 = "CREATE TABLE followers ( id INT(50) NOT NULL AUTO_INCREMENT , username VARCHAR(50) NOT NULL , follower VARCHAR(50) NOT NULL ,followed_on DATE NOT NULL, PRIMARY KEY (`id`) )";   

   $table5 = "CREATE TABLE tags ( tag_id INT(50) NOT NULL AUTO_INCREMENT , post_id INT(50) NOT NULL, username VARCHAR(50) NOT NULL , tag VARCHAR(50) NOT NULL , PRIMARY KEY (`tag_id`) )";   
   
   $table6 = "CREATE TABLE hobbies ( hobby_id INT(50) NOT NULL AUTO_INCREMENT , username VARCHAR(50) NOT NULL , hobby VARCHAR(50) NOT NULL, PRIMARY KEY (`hobby_id`) )";   
   
   $tables = [$table1, $table2,$table3,$table4,$table5,$table6];

   foreach($tables as $k => $sql){
    $query = @$con->query($sql);

    if(!$query)
       $errors[] = "Table $k : Creation failed ($con->error)";
    else
       $errors[] = "Table $k : Creation done";
   }

}
?>
<!doctype html>
<html class="no-js" lang="">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>University Login Page</title>
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
   <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"
      integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous">
   </script>
   <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
      integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous">
   </script>
   <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
   <link href="styles/styles.css" rel="stylesheet" type="text/css">
</head>

<body>

   <div class="login-content">
      <div id="form" class="login-form shadow">
         <form method="post">
            <div>
               <h2 class="title font-semibold text-xl">University Student Login</h2>
            </div>
            <div class="form-group my-4">
               <label id="label" class="my-2"> &nbsp;Username </label>
               <input type="text" name="username" class="form-control" placeholder="username" required>
            </div>
            <div class="form-group my-4">
               <label id="label" class="my-2">Password</label>
               <input type="password" name="password" class="form-control" placeholder="Password" required>
            </div>
            <div class="d-flex flex-row justify-content-between align-items-center my-4">
               <button type="submit" class="btn btn-success btn-flat">Sign in</button>
               <a href='login.php?init=true'>
                  <button type="button" name="init" class="btn btn-success btn-flat">Initialise Database</button>
               </a>
            </div>
            <?php foreach($errors as $msg) { ?>
            <div class="alert alert-success my-4" role="alert"><?php echo $msg ?></div>
            <?php } ?>
            <?php if ($error_msg != '') { ?>
            <div class="alert alert-danger my-4" role="alert"><?php echo $error_msg ?></div>
            <?php } ?>
         </form>
         <div class="relative">
            <div class="absolute inset-0 flex items-center">
               <div class="w-full border-t border-gray-300"></div>
            </div>
            <div class="relative flex justify-center text-md">
               <span class="px-2 bg-white text-gray-800"> Or </span>
            </div>
         </div>
         <div class="form-group my-4">
            <a href='register.php'>
               <button type="button" name="init" class="btn btn-primary form-control">Signup</button>
            </a>
         </div>
      </div>
   </div>

</body>

</html>