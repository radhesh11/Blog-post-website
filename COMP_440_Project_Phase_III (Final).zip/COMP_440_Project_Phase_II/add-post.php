<?php
require('db.inc.php');
$msg = "";
$error_msg = "";
$subject = "";
$description = "";
$tags = "";
$username=$_SESSION['USERNAME'];
$createdOn=date("Y-m-d");
$count=0;
if(!isset($_SESSION['USERNAME'])){
	header('location:login.php');
	die();
}
if (isset($_POST['submit'])) {
    $query="select count(post_id) as total from posts where username='$username' and created_on='$createdOn'";
    $result=mysqli_query($con,$query);
    if (mysqli_num_rows($result) > 0) {
        while($total = mysqli_fetch_assoc($result)){
            $count= $total["total"];
        }
    }
    if($count < 2){
        $subject = mysqli_real_escape_string($con, $_POST['subject']);
        $description = mysqli_real_escape_string($con, $_POST['description']);
        $tags = $_POST['tags'];
        // $tags = mysqli_real_escape_string($con, $_POST['tags']);
        echo "<script> alert(`Hi $username,$description,$createdOn`)</script>";
        $sql = "insert into posts(subject,description,created_on,username) values('$subject','$description','$createdOn','$username')";
          if ($con->query($sql) === TRUE) {
             $msg = "Posted Successful";
             echo "<script> alert('Posted Successful')</script>";
             $post_id = mysqli_insert_id($con);
            //  header('location:home.php');
          } else {
             echo "<script> alert('Error posting')</script>";
             $error_msg = "Error posting: " . $con->error;
          }
          foreach ($tags as $tag) {
            echo "<script> alert(`Hi $tag $post_id`)</script>";
            $insertTags="insert into tags(post_id,username,tag) values('$post_id','$username','$tag')";
            if ($con->query($insertTags) === TRUE) {
                echo "<script> alert('Posted Successful')</script>";
                header('location:home.php');
             } else {
                echo "<script> alert('Error posting')</script>";
                $error_msg = "Error posting: " . $con->error;
             }
         }
    }
    else{
        $error_msg = "Max Limit Reached. A user can post only 2 posts a day ";
    }
 }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Post</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"
        integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"
        integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous">
    </script>
    <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
    <link href="styles/styles.css" rel="stylesheet" type="text/css">
</head>

<body>
    <div>
        <nav class="navbar navbar-expand-lg navbar-light bg-light px-4 py-3">
            <a class="navbar-brand" href="#">Blog Website</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="home.php">Home <span class="sr-only">(current)</span></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="more-details.php">More Details <span class="sr-only">(current)</span></a>
                    </li>
                </ul>
                <a href="logout.php" class="ml-4">
                    <button type="button" class="btn btn-danger">Logout</button>
                </a>
            </div>
        </nav>
        <div class="p-4 mx-auto w-2/3 space-y-4">
            <p class="text-xl font-bold">Create Post</p>
            <form class="space-y-4" method="post">
                <div class="form-group space-y-2">
                    <label for="exampleInputEmail1">Subject</label>
                    <input type="text" name="subject" required class="form-control" id="exampleInputEmail1">
                </div>
                <div class="form-group space-y-2">
                    <label for="exampleFormControlTextarea1">Description</label>
                    <textarea class="form-control" name="description" required id="exampleFormControlTextarea1"
                        rows="3"></textarea>
                </div>
                <div class="form-group space-y-2">
                    <label for="exampleFormControlSelect1">Tags</label>
                    <select name="tags[]" class="form-control" multiple="multiple" id="exampleFormControlSelect1">
                        <option>Blockchain</option>
                        <option>Bitcoin</option>
                        <option>Decentralized</option>
                    </select>
                </div>
                <button type="submit" name="submit" class="btn btn-success">Add Post</button>
                <?php if ($error_msg != '') { ?>
                <div class="alert alert-danger my-4" role="alert"><?php echo $error_msg ?></div>
                <?php } ?>
            </form>
        </div>
    </div>
</body>

</html>